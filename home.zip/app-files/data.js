var APP_DATA = {
  "scenes": [
    {
      "id": "0-street-view-360",
      "name": "Street View 360",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1792,
      "initialViewParameters": {
        "yaw": -0.11646467487420864,
        "pitch": -0.23651466801106835,
        "fov": 1.325599857056214
      },
      "linkHotspots": [],
      "infoHotspots": []
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
